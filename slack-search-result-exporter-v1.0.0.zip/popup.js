/// <reference types="chrome"/>
import { DatePresetManager } from './date-preset-manager.js';
import { formatUserError } from './error-messages.js';
/**
 * Popup UI Controller
 */
class PopupUIController {
    constructor() {
        this.datePresetManager = new DatePresetManager();
        this.state = {
            selectedPreset: 'week', // Default preset
            isExporting: false,
            exportResult: null,
            error: null
        };
        // Get DOM elements
        this.elements = {
            presetButtons: document.querySelectorAll('.preset-button'),
            exportButton: document.getElementById('export-btn'),
            progress: document.getElementById('progress'),
            progressText: document.getElementById('progress-text'),
            resultSection: document.getElementById('result-section'),
            resultText: document.getElementById('result-text'),
            messageCount: document.getElementById('message-count'),
            copyButton: document.getElementById('copy-btn'),
            errorMessage: document.getElementById('error-message')
        };
        this.init();
    }
    /**
     * Initialize UI and load settings
     */
    async init() {
        await this.loadSettings();
        this.attachEventListeners();
    }
    /**
     * Load settings from Service Worker
     */
    async loadSettings() {
        try {
            const message = { type: 'GET_SETTINGS' };
            const response = await chrome.runtime.sendMessage(message);
            if (this.isServiceWorkerResponse(response)) {
                if (response.type === 'SETTINGS_LOADED') {
                    this.state.selectedPreset = response.payload.selectedPreset;
                    this.updatePresetButtons();
                }
                else if (response.type === 'SETTINGS_ERROR') {
                    console.error('Settings load error:', response.error);
                    // Use default preset
                    this.updatePresetButtons();
                }
            }
        }
        catch (error) {
            console.error('Failed to load settings:', error);
            // Use default preset
            this.updatePresetButtons();
        }
    }
    /**
     * Type guard for Service Worker response
     */
    isServiceWorkerResponse(response) {
        return (typeof response === 'object' &&
            response !== null &&
            'type' in response);
    }
    /**
     * Type guard for Content Script response
     */
    isContentScriptResponse(response) {
        return (typeof response === 'object' &&
            response !== null &&
            'type' in response);
    }
    /**
     * Update preset button UI
     */
    updatePresetButtons() {
        this.elements.presetButtons.forEach(button => {
            const preset = button.getAttribute('data-preset');
            if (preset === this.state.selectedPreset) {
                button.classList.add('selected');
            }
            else {
                button.classList.remove('selected');
            }
        });
    }
    /**
     * Attach event listeners
     */
    attachEventListeners() {
        // Preset button click
        this.elements.presetButtons.forEach(button => {
            button.addEventListener('click', () => this.onPresetClick(button));
        });
        // Export button click
        this.elements.exportButton.addEventListener('click', () => this.onExportClick());
        // Copy button click
        this.elements.copyButton.addEventListener('click', () => this.onCopyClick());
    }
    /**
     * Handle preset button click
     * Applies date preset query and starts export
     */
    async onPresetClick(button) {
        const preset = button.getAttribute('data-preset');
        if (!preset)
            return;
        this.state.selectedPreset = preset;
        this.updatePresetButtons();
        // Save to Service Worker
        try {
            const message = {
                type: 'SAVE_SETTINGS',
                payload: { selectedPreset: preset }
            };
            await chrome.runtime.sendMessage(message);
        }
        catch (error) {
            console.error('Failed to save settings:', error);
        }
        // Apply date preset query to Slack search
        await this.applyDatePreset(preset);
    }
    /**
     * Apply date preset query to Slack search
     * Then automatically start export
     */
    async applyDatePreset(preset) {
        try {
            // Get active tab
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab.id) {
                throw new Error('No active tab found');
            }
            // Generate date query string
            const query = this.datePresetManager.toSlackQuery(preset);
            // Send apply preset message to Content Script
            const message = {
                type: 'APPLY_DATE_PRESET',
                preset,
                query
            };
            const response = await chrome.tabs.sendMessage(tab.id, message);
            if (this.isContentScriptResponse(response) && response.type === 'PRESET_APPLIED') {
                if (response.success) {
                    // Wait for search to complete
                    await this.waitMilliseconds(1500);
                    // Automatically start export
                    await this.onExportClick();
                }
                else {
                    this.showError({
                        code: 'EXPORT_ERROR',
                        message: response.message || 'プリセット適用に失敗しました'
                    });
                }
            }
        }
        catch (error) {
            console.error('Failed to apply date preset:', error);
            this.showError({
                code: 'EXPORT_ERROR',
                message: error instanceof Error ? error.message : 'プリセット適用に失敗しました'
            });
        }
    }
    /**
     * Wait for specified milliseconds
     */
    waitMilliseconds(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    /**
     * Handle export button click
     */
    async onExportClick() {
        if (this.state.isExporting)
            return;
        this.state.isExporting = true;
        this.state.error = null;
        this.updateUI();
        try {
            // Get active tab
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab.id) {
                throw new Error('No active tab found');
            }
            // Send export message to Content Script
            const message = {
                type: 'START_EXPORT',
                options: {
                    datePreset: this.state.selectedPreset
                }
            };
            const response = await chrome.tabs.sendMessage(tab.id, message);
            if (this.isContentScriptResponse(response)) {
                if (response.type === 'EXPORT_COMPLETE') {
                    this.state.exportResult = response.payload;
                    this.state.isExporting = false;
                    this.updateUI();
                }
                else if (response.type === 'EXPORT_ERROR') {
                    this.state.error = response.error;
                    this.state.isExporting = false;
                    this.updateUI();
                }
            }
        }
        catch (error) {
            console.error('Export error:', error);
            this.state.error = {
                code: 'EXPORT_ERROR',
                message: error instanceof Error ? error.message : 'エクスポートに失敗しました'
            };
            this.state.isExporting = false;
            this.updateUI();
        }
    }
    /**
     * Handle copy button click
     */
    async onCopyClick() {
        if (!this.state.exportResult)
            return;
        try {
            const tsvText = this.state.exportResult.messages.join('\n');
            await navigator.clipboard.writeText(tsvText);
            // Show success feedback
            const originalText = this.elements.copyButton.textContent;
            this.elements.copyButton.textContent = 'コピーしました!';
            setTimeout(() => {
                this.elements.copyButton.textContent = originalText;
            }, 2000);
        }
        catch (error) {
            console.error('Failed to copy to clipboard:', error);
            this.showError({
                code: 'CLIPBOARD_ERROR',
                message: 'クリップボードへのコピーに失敗しました'
            });
        }
    }
    /**
     * Update UI based on state
     */
    updateUI() {
        // Update export button
        this.elements.exportButton.disabled = this.state.isExporting;
        // Update progress indicator
        if (this.state.isExporting) {
            this.elements.progress.style.display = 'flex';
            this.elements.resultSection.style.display = 'none';
            this.elements.errorMessage.style.display = 'none';
        }
        else {
            this.elements.progress.style.display = 'none';
        }
        // Update result section
        if (this.state.exportResult && !this.state.isExporting) {
            this.elements.resultSection.style.display = 'block';
            this.elements.messageCount.textContent = this.state.exportResult.messageCount.toString();
            this.elements.resultText.value = this.state.exportResult.messages.join('\n');
            this.elements.errorMessage.style.display = 'none';
        }
        else if (!this.state.isExporting) {
            this.elements.resultSection.style.display = 'none';
        }
        // Update error message
        if (this.state.error && !this.state.isExporting) {
            this.showError(this.state.error);
        }
    }
    /**
     * Show error message with user-friendly formatting
     */
    showError(error) {
        // Format error for user display (hides technical details)
        const userMessage = formatUserError(error);
        this.elements.errorMessage.textContent = userMessage;
        this.elements.errorMessage.style.display = 'block';
        // Log detailed error for development/debugging (not shown to user)
        console.error('Error details:', error);
    }
}
// Initialize Popup UI when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new PopupUIController();
});
//# sourceMappingURL=popup.js.map